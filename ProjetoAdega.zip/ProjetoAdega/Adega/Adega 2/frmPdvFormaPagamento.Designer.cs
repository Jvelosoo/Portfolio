﻿
namespace Adega_2
{
    partial class frmPdvFormaPagamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPdvFormaPagamento));
            this.pnlPdvFormaPagamento = new System.Windows.Forms.Panel();
            this.btnVoltar = new System.Windows.Forms.Button();
            this.btnCartaoCredito = new System.Windows.Forms.Button();
            this.btnCartaoDebito = new System.Windows.Forms.Button();
            this.btnPix = new System.Windows.Forms.Button();
            this.btnDinheiro = new System.Windows.Forms.Button();
            this.lblFormaPagamento = new System.Windows.Forms.Label();
            this.pnlPdvFormaPagamento.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlPdvFormaPagamento
            // 
            this.pnlPdvFormaPagamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlPdvFormaPagamento.Controls.Add(this.btnVoltar);
            this.pnlPdvFormaPagamento.Controls.Add(this.btnCartaoCredito);
            this.pnlPdvFormaPagamento.Controls.Add(this.btnCartaoDebito);
            this.pnlPdvFormaPagamento.Controls.Add(this.btnPix);
            this.pnlPdvFormaPagamento.Controls.Add(this.btnDinheiro);
            this.pnlPdvFormaPagamento.Controls.Add(this.lblFormaPagamento);
            this.pnlPdvFormaPagamento.Location = new System.Drawing.Point(13, 13);
            this.pnlPdvFormaPagamento.Name = "pnlPdvFormaPagamento";
            this.pnlPdvFormaPagamento.Size = new System.Drawing.Size(1001, 573);
            this.pnlPdvFormaPagamento.TabIndex = 0;
            // 
            // btnVoltar
            // 
            this.btnVoltar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVoltar.ForeColor = System.Drawing.Color.White;
            this.btnVoltar.Location = new System.Drawing.Point(46, 509);
            this.btnVoltar.Name = "btnVoltar";
            this.btnVoltar.Size = new System.Drawing.Size(88, 35);
            this.btnVoltar.TabIndex = 6;
            this.btnVoltar.Text = "Voltar";
            this.btnVoltar.UseVisualStyleBackColor = true;
            this.btnVoltar.Click += new System.EventHandler(this.btnVoltar_Click);
            // 
            // btnCartaoCredito
            // 
            this.btnCartaoCredito.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.btnCartaoCredito.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnCartaoCredito.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCartaoCredito.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnCartaoCredito.ForeColor = System.Drawing.Color.White;
            this.btnCartaoCredito.Image = ((System.Drawing.Image)(resources.GetObject("btnCartaoCredito.Image")));
            this.btnCartaoCredito.Location = new System.Drawing.Point(642, 349);
            this.btnCartaoCredito.Name = "btnCartaoCredito";
            this.btnCartaoCredito.Size = new System.Drawing.Size(177, 150);
            this.btnCartaoCredito.TabIndex = 5;
            this.btnCartaoCredito.Text = "Cartão de Crédito";
            this.btnCartaoCredito.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCartaoCredito.UseVisualStyleBackColor = false;
            // 
            // btnCartaoDebito
            // 
            this.btnCartaoDebito.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.btnCartaoDebito.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnCartaoDebito.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCartaoDebito.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnCartaoDebito.ForeColor = System.Drawing.Color.White;
            this.btnCartaoDebito.Image = ((System.Drawing.Image)(resources.GetObject("btnCartaoDebito.Image")));
            this.btnCartaoDebito.Location = new System.Drawing.Point(219, 349);
            this.btnCartaoDebito.Name = "btnCartaoDebito";
            this.btnCartaoDebito.Size = new System.Drawing.Size(177, 150);
            this.btnCartaoDebito.TabIndex = 4;
            this.btnCartaoDebito.Text = "Cartão de Débito";
            this.btnCartaoDebito.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCartaoDebito.UseVisualStyleBackColor = false;
            // 
            // btnPix
            // 
            this.btnPix.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.btnPix.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnPix.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPix.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnPix.ForeColor = System.Drawing.Color.White;
            this.btnPix.Image = ((System.Drawing.Image)(resources.GetObject("btnPix.Image")));
            this.btnPix.Location = new System.Drawing.Point(642, 156);
            this.btnPix.Name = "btnPix";
            this.btnPix.Size = new System.Drawing.Size(177, 150);
            this.btnPix.TabIndex = 3;
            this.btnPix.Text = "Pix";
            this.btnPix.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPix.UseVisualStyleBackColor = false;
            // 
            // btnDinheiro
            // 
            this.btnDinheiro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.btnDinheiro.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnDinheiro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDinheiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnDinheiro.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnDinheiro.Image = ((System.Drawing.Image)(resources.GetObject("btnDinheiro.Image")));
            this.btnDinheiro.Location = new System.Drawing.Point(219, 156);
            this.btnDinheiro.Name = "btnDinheiro";
            this.btnDinheiro.Size = new System.Drawing.Size(177, 150);
            this.btnDinheiro.TabIndex = 2;
            this.btnDinheiro.Text = "Dinheiro";
            this.btnDinheiro.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDinheiro.UseVisualStyleBackColor = false;
            this.btnDinheiro.Click += new System.EventHandler(this.btnDinheiro_Click_1);
            // 
            // lblFormaPagamento
            // 
            this.lblFormaPagamento.AutoSize = true;
            this.lblFormaPagamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.lblFormaPagamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(0)))));
            this.lblFormaPagamento.Location = new System.Drawing.Point(211, 39);
            this.lblFormaPagamento.Name = "lblFormaPagamento";
            this.lblFormaPagamento.Size = new System.Drawing.Size(608, 46);
            this.lblFormaPagamento.TabIndex = 0;
            this.lblFormaPagamento.Text = "Selecione a forma de pagamento";
            // 
            // frmPdvFormaPagamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(1026, 598);
            this.Controls.Add(this.pnlPdvFormaPagamento);
            this.Name = "frmPdvFormaPagamento";
            this.Text = "frmPdvFormaPagamento";
            this.pnlPdvFormaPagamento.ResumeLayout(false);
            this.pnlPdvFormaPagamento.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlPdvFormaPagamento;
        private System.Windows.Forms.Label lblFormaPagamento;
        private System.Windows.Forms.Button btnCartaoCredito;
        private System.Windows.Forms.Button btnCartaoDebito;
        private System.Windows.Forms.Button btnPix;
        private System.Windows.Forms.Button btnDinheiro;
        private System.Windows.Forms.Button btnVoltar;
    }
}