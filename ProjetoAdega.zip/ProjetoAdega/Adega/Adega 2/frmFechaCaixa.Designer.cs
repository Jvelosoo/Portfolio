﻿
namespace Adega_2
{
    partial class frmFecharCaixa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFecharCaixa));
            this.pnlFechaCaixa = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.btnAvancar = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.lblValorCaixa = new System.Windows.Forms.Label();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.lblCaixa = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.picBoxCaixa = new System.Windows.Forms.PictureBox();
            this.lblDinheiroRetirada = new System.Windows.Forms.Label();
            this.lblRetirada = new System.Windows.Forms.Label();
            this.picBoxDinheiroRetirada = new System.Windows.Forms.PictureBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.lblGanhosHj = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lblFechamentoDeCaixa = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.grpGanhos = new System.Windows.Forms.GroupBox();
            this.lblPixValor = new System.Windows.Forms.Label();
            this.lblPixIcon = new System.Windows.Forms.Label();
            this.picBoxPix = new System.Windows.Forms.PictureBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.lblPix = new System.Windows.Forms.Label();
            this.lblValorTotal = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lblTotal = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblValorDebito = new System.Windows.Forms.Label();
            this.lblDebito = new System.Windows.Forms.Label();
            this.picBoxDebito = new System.Windows.Forms.PictureBox();
            this.lblValorCredito = new System.Windows.Forms.Label();
            this.lblCredito = new System.Windows.Forms.Label();
            this.picBoxCredito = new System.Windows.Forms.PictureBox();
            this.lblValorDinheiro = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.picBoxDinheiro = new System.Windows.Forms.PictureBox();
            this.lblDinheiro1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblDinheiro = new System.Windows.Forms.Label();
            this.lblValor = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblFormaDePagamento = new System.Windows.Forms.Label();
            this.pnlFechaCaixa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCaixa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxDinheiroRetirada)).BeginInit();
            this.grpGanhos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPix)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxDebito)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCredito)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxDinheiro)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlFechaCaixa
            // 
            this.pnlFechaCaixa.Controls.Add(this.panel18);
            this.pnlFechaCaixa.Controls.Add(this.btnAvancar);
            this.pnlFechaCaixa.Controls.Add(this.panel15);
            this.pnlFechaCaixa.Controls.Add(this.lblValorCaixa);
            this.pnlFechaCaixa.Controls.Add(this.txtValor);
            this.pnlFechaCaixa.Controls.Add(this.lblCaixa);
            this.pnlFechaCaixa.Controls.Add(this.panel16);
            this.pnlFechaCaixa.Controls.Add(this.panel14);
            this.pnlFechaCaixa.Controls.Add(this.panel17);
            this.pnlFechaCaixa.Controls.Add(this.panel13);
            this.pnlFechaCaixa.Controls.Add(this.panel12);
            this.pnlFechaCaixa.Controls.Add(this.picBoxCaixa);
            this.pnlFechaCaixa.Controls.Add(this.lblDinheiroRetirada);
            this.pnlFechaCaixa.Controls.Add(this.lblRetirada);
            this.pnlFechaCaixa.Controls.Add(this.picBoxDinheiroRetirada);
            this.pnlFechaCaixa.Controls.Add(this.panel11);
            this.pnlFechaCaixa.Controls.Add(this.lblGanhosHj);
            this.pnlFechaCaixa.Controls.Add(this.panel10);
            this.pnlFechaCaixa.Controls.Add(this.lblFechamentoDeCaixa);
            this.pnlFechaCaixa.Controls.Add(this.panel7);
            this.pnlFechaCaixa.Controls.Add(this.panel6);
            this.pnlFechaCaixa.Controls.Add(this.grpGanhos);
            this.pnlFechaCaixa.Location = new System.Drawing.Point(13, 10);
            this.pnlFechaCaixa.Name = "pnlFechaCaixa";
            this.pnlFechaCaixa.Size = new System.Drawing.Size(775, 425);
            this.pnlFechaCaixa.TabIndex = 0;

            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel18.Location = new System.Drawing.Point(18, 255);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(10, 1);
            this.panel18.TabIndex = 5;
            // 
            // btnAvancar
            // 
            this.btnAvancar.BackColor = System.Drawing.Color.DarkGreen;
            this.btnAvancar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAvancar.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.btnAvancar.Location = new System.Drawing.Point(568, 364);
            this.btnAvancar.Name = "btnAvancar";
            this.btnAvancar.Size = new System.Drawing.Size(75, 35);
            this.btnAvancar.TabIndex = 25;
            this.btnAvancar.Text = "Avançar";
            this.btnAvancar.UseVisualStyleBackColor = false;
            this.btnAvancar.Click += new System.EventHandler(this.btnAvancar_Click);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel15.Location = new System.Drawing.Point(471, 303);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(100, 1);
            this.panel15.TabIndex = 6;
            // 
            // lblValorCaixa
            // 
            this.lblValorCaixa.AutoSize = true;
            this.lblValorCaixa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Bold);
            this.lblValorCaixa.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblValorCaixa.Location = new System.Drawing.Point(467, 283);
            this.lblValorCaixa.Name = "lblValorCaixa";
            this.lblValorCaixa.Size = new System.Drawing.Size(89, 20);
            this.lblValorCaixa.TabIndex = 23;
            this.lblValorCaixa.Text = "Valor : R$";
            // 
            // txtValor
            // 
            this.txtValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValor.ForeColor = System.Drawing.Color.DarkGreen;
            this.txtValor.Location = new System.Drawing.Point(471, 311);
            this.txtValor.Multiline = true;
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(172, 46);
            this.txtValor.TabIndex = 22;
            this.txtValor.Text = "0,00";
            this.txtValor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtValor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValor_KeyPress);
            // 
            // lblCaixa
            // 
            this.lblCaixa.AutoSize = true;
            this.lblCaixa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCaixa.ForeColor = System.Drawing.SystemColors.Window;
            this.lblCaixa.Location = new System.Drawing.Point(276, 283);
            this.lblCaixa.Name = "lblCaixa";
            this.lblCaixa.Size = new System.Drawing.Size(55, 15);
            this.lblCaixa.TabIndex = 21;
            this.lblCaixa.Text = "Caixa 1";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel16.Location = new System.Drawing.Point(18, 38);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(100, 1);
            this.panel16.TabIndex = 5;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel14.Location = new System.Drawing.Point(279, 302);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(1, 94);
            this.panel14.TabIndex = 4;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel17.Location = new System.Drawing.Point(378, 302);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(1, 94);
            this.panel17.TabIndex = 3;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel13.Location = new System.Drawing.Point(279, 396);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(100, 1);
            this.panel13.TabIndex = 5;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel12.Location = new System.Drawing.Point(279, 301);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(100, 1);
            this.panel12.TabIndex = 4;
            // 
            // picBoxCaixa
            // 
            this.picBoxCaixa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picBoxCaixa.ErrorImage = null;
            this.picBoxCaixa.Image = ((System.Drawing.Image)(resources.GetObject("picBoxCaixa.Image")));
            this.picBoxCaixa.InitialImage = ((System.Drawing.Image)(resources.GetObject("picBoxCaixa.InitialImage")));
            this.picBoxCaixa.Location = new System.Drawing.Point(283, 301);
            this.picBoxCaixa.Name = "picBoxCaixa";
            this.picBoxCaixa.Size = new System.Drawing.Size(96, 96);
            this.picBoxCaixa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBoxCaixa.TabIndex = 20;
            this.picBoxCaixa.TabStop = false;
            // 
            // lblDinheiroRetirada
            // 
            this.lblDinheiroRetirada.AutoSize = true;
            this.lblDinheiroRetirada.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblDinheiroRetirada.ForeColor = System.Drawing.Color.Green;
            this.lblDinheiroRetirada.Location = new System.Drawing.Point(553, 126);
            this.lblDinheiroRetirada.Name = "lblDinheiroRetirada";
            this.lblDinheiroRetirada.Size = new System.Drawing.Size(71, 18);
            this.lblDinheiroRetirada.TabIndex = 19;
            this.lblDinheiroRetirada.Text = "Dinheiro";
            // 
            // lblRetirada
            // 
            this.lblRetirada.AutoSize = true;
            this.lblRetirada.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblRetirada.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblRetirada.Location = new System.Drawing.Point(398, 126);
            this.lblRetirada.Name = "lblRetirada";
            this.lblRetirada.Size = new System.Drawing.Size(168, 18);
            this.lblRetirada.TabIndex = 18;
            this.lblRetirada.Text = "Forma de Retirada :  ";
            // 
            // picBoxDinheiroRetirada
            // 
            this.picBoxDinheiroRetirada.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picBoxDinheiroRetirada.ErrorImage = null;
            this.picBoxDinheiroRetirada.Image = ((System.Drawing.Image)(resources.GetObject("picBoxDinheiroRetirada.Image")));
            this.picBoxDinheiroRetirada.InitialImage = ((System.Drawing.Image)(resources.GetObject("picBoxDinheiroRetirada.InitialImage")));
            this.picBoxDinheiroRetirada.Location = new System.Drawing.Point(315, 106);
            this.picBoxDinheiroRetirada.Name = "picBoxDinheiroRetirada";
            this.picBoxDinheiroRetirada.Size = new System.Drawing.Size(64, 56);
            this.picBoxDinheiroRetirada.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBoxDinheiroRetirada.TabIndex = 17;
            this.picBoxDinheiroRetirada.TabStop = false;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel11.Location = new System.Drawing.Point(245, 178);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(520, 1);
            this.panel11.TabIndex = 4;
            // 
            // lblGanhosHj
            // 
            this.lblGanhosHj.AutoSize = true;
            this.lblGanhosHj.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblGanhosHj.ForeColor = System.Drawing.SystemColors.Window;
            this.lblGanhosHj.Location = new System.Drawing.Point(15, 21);
            this.lblGanhosHj.Name = "lblGanhosHj";
            this.lblGanhosHj.Size = new System.Drawing.Size(90, 15);
            this.lblGanhosHj.TabIndex = 1;
            this.lblGanhosHj.Text = "Ganhos Hoje";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel10.Location = new System.Drawing.Point(245, 93);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(520, 1);
            this.panel10.TabIndex = 3;
            // 
            // lblFechamentoDeCaixa
            // 
            this.lblFechamentoDeCaixa.AutoSize = true;
            this.lblFechamentoDeCaixa.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechamentoDeCaixa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(0)))));
            this.lblFechamentoDeCaixa.Location = new System.Drawing.Point(342, 39);
            this.lblFechamentoDeCaixa.Name = "lblFechamentoDeCaixa";
            this.lblFechamentoDeCaixa.Size = new System.Drawing.Size(348, 37);
            this.lblFechamentoDeCaixa.TabIndex = 5;
            this.lblFechamentoDeCaixa.Text = "Fechamento de Caixa";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel7.Location = new System.Drawing.Point(18, 155);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(10, 1);
            this.panel7.TabIndex = 4;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel6.Location = new System.Drawing.Point(18, 99);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 1);
            this.panel6.TabIndex = 3;
            // 
            // grpGanhos
            // 
            this.grpGanhos.BackColor = System.Drawing.Color.White;
            this.grpGanhos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.grpGanhos.Controls.Add(this.lblPixValor);
            this.grpGanhos.Controls.Add(this.lblPixIcon);
            this.grpGanhos.Controls.Add(this.picBoxPix);
            this.grpGanhos.Controls.Add(this.panel19);
            this.grpGanhos.Controls.Add(this.lblPix);
            this.grpGanhos.Controls.Add(this.lblValorTotal);
            this.grpGanhos.Controls.Add(this.panel9);
            this.grpGanhos.Controls.Add(this.lblTotal);
            this.grpGanhos.Controls.Add(this.panel2);
            this.grpGanhos.Controls.Add(this.lblValorDebito);
            this.grpGanhos.Controls.Add(this.lblDebito);
            this.grpGanhos.Controls.Add(this.picBoxDebito);
            this.grpGanhos.Controls.Add(this.lblValorCredito);
            this.grpGanhos.Controls.Add(this.lblCredito);
            this.grpGanhos.Controls.Add(this.picBoxCredito);
            this.grpGanhos.Controls.Add(this.lblValorDinheiro);
            this.grpGanhos.Controls.Add(this.panel8);
            this.grpGanhos.Controls.Add(this.label2);
            this.grpGanhos.Controls.Add(this.picBoxDinheiro);
            this.grpGanhos.Controls.Add(this.lblDinheiro1);
            this.grpGanhos.Controls.Add(this.panel5);
            this.grpGanhos.Controls.Add(this.lblDinheiro);
            this.grpGanhos.Controls.Add(this.lblValor);
            this.grpGanhos.Controls.Add(this.panel3);
            this.grpGanhos.Controls.Add(this.panel4);
            this.grpGanhos.Controls.Add(this.panel1);
            this.grpGanhos.Controls.Add(this.lblFormaDePagamento);
            this.grpGanhos.Location = new System.Drawing.Point(18, 41);
            this.grpGanhos.Name = "grpGanhos";
            this.grpGanhos.Size = new System.Drawing.Size(216, 358);
            this.grpGanhos.TabIndex = 0;
            this.grpGanhos.TabStop = false;
            // 
            // lblPixValor
            // 
            this.lblPixValor.AutoSize = true;
            this.lblPixValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPixValor.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblPixValor.Location = new System.Drawing.Point(159, 227);
            this.lblPixValor.Name = "lblPixValor";
            this.lblPixValor.Size = new System.Drawing.Size(36, 16);
            this.lblPixValor.TabIndex = 21;
            this.lblPixValor.Text = "0,00";
            // 
            // lblPixIcon
            // 
            this.lblPixIcon.AutoSize = true;
            this.lblPixIcon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F);
            this.lblPixIcon.Location = new System.Drawing.Point(44, 231);
            this.lblPixIcon.Name = "lblPixIcon";
            this.lblPixIcon.Size = new System.Drawing.Size(26, 16);
            this.lblPixIcon.TabIndex = 20;
            this.lblPixIcon.Text = "Pix";
            // 
            // picBoxPix
            // 
            this.picBoxPix.ErrorImage = ((System.Drawing.Image)(resources.GetObject("picBoxPix.ErrorImage")));
            this.picBoxPix.Image = ((System.Drawing.Image)(resources.GetObject("picBoxPix.Image")));
            this.picBoxPix.InitialImage = ((System.Drawing.Image)(resources.GetObject("picBoxPix.InitialImage")));
            this.picBoxPix.Location = new System.Drawing.Point(16, 227);
            this.picBoxPix.Name = "picBoxPix";
            this.picBoxPix.Size = new System.Drawing.Size(20, 20);
            this.picBoxPix.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBoxPix.TabIndex = 19;
            this.picBoxPix.TabStop = false;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel19.Location = new System.Drawing.Point(47, 214);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(180, 1);
            this.panel19.TabIndex = 4;
            // 
            // lblPix
            // 
            this.lblPix.AutoSize = true;
            this.lblPix.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPix.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblPix.Location = new System.Drawing.Point(14, 205);
            this.lblPix.Name = "lblPix";
            this.lblPix.Size = new System.Drawing.Size(27, 15);
            this.lblPix.TabIndex = 18;
            this.lblPix.Text = "Pix";
            // 
            // lblValorTotal
            // 
            this.lblValorTotal.AutoSize = true;
            this.lblValorTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorTotal.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblValorTotal.Location = new System.Drawing.Point(78, 330);
            this.lblValorTotal.Name = "lblValorTotal";
            this.lblValorTotal.Size = new System.Drawing.Size(54, 25);
            this.lblValorTotal.TabIndex = 16;
            this.lblValorTotal.Text = "0,00";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel9.Location = new System.Drawing.Point(74, 315);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(160, 1);
            this.panel9.TabIndex = 4;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblTotal.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblTotal.Location = new System.Drawing.Point(22, 306);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(46, 18);
            this.lblTotal.TabIndex = 15;
            this.lblTotal.Text = "Total";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel2.Location = new System.Drawing.Point(0, 315);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 1);
            this.panel2.TabIndex = 5;
            // 
            // lblValorDebito
            // 
            this.lblValorDebito.AutoSize = true;
            this.lblValorDebito.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorDebito.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblValorDebito.Location = new System.Drawing.Point(159, 172);
            this.lblValorDebito.Name = "lblValorDebito";
            this.lblValorDebito.Size = new System.Drawing.Size(36, 16);
            this.lblValorDebito.TabIndex = 14;
            this.lblValorDebito.Text = "0,00";
            // 
            // lblDebito
            // 
            this.lblDebito.AutoSize = true;
            this.lblDebito.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F);
            this.lblDebito.Location = new System.Drawing.Point(43, 175);
            this.lblDebito.Name = "lblDebito";
            this.lblDebito.Size = new System.Drawing.Size(48, 16);
            this.lblDebito.TabIndex = 13;
            this.lblDebito.Text = "Débito";
            // 
            // picBoxDebito
            // 
            this.picBoxDebito.ErrorImage = ((System.Drawing.Image)(resources.GetObject("picBoxDebito.ErrorImage")));
            this.picBoxDebito.Image = ((System.Drawing.Image)(resources.GetObject("picBoxDebito.Image")));
            this.picBoxDebito.InitialImage = ((System.Drawing.Image)(resources.GetObject("picBoxDebito.InitialImage")));
            this.picBoxDebito.Location = new System.Drawing.Point(14, 172);
            this.picBoxDebito.Name = "picBoxDebito";
            this.picBoxDebito.Size = new System.Drawing.Size(20, 20);
            this.picBoxDebito.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBoxDebito.TabIndex = 12;
            this.picBoxDebito.TabStop = false;
            // 
            // lblValorCredito
            // 
            this.lblValorCredito.AutoSize = true;
            this.lblValorCredito.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorCredito.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblValorCredito.Location = new System.Drawing.Point(159, 135);
            this.lblValorCredito.Name = "lblValorCredito";
            this.lblValorCredito.Size = new System.Drawing.Size(36, 16);
            this.lblValorCredito.TabIndex = 11;
            this.lblValorCredito.Text = "0,00";
            // 
            // lblCredito
            // 
            this.lblCredito.AutoSize = true;
            this.lblCredito.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F);
            this.lblCredito.Location = new System.Drawing.Point(43, 137);
            this.lblCredito.Name = "lblCredito";
            this.lblCredito.Size = new System.Drawing.Size(51, 16);
            this.lblCredito.TabIndex = 10;
            this.lblCredito.Text = "Crédito";
            // 
            // picBoxCredito
            // 
            this.picBoxCredito.ErrorImage = ((System.Drawing.Image)(resources.GetObject("picBoxCredito.ErrorImage")));
            this.picBoxCredito.Image = ((System.Drawing.Image)(resources.GetObject("picBoxCredito.Image")));
            this.picBoxCredito.InitialImage = ((System.Drawing.Image)(resources.GetObject("picBoxCredito.InitialImage")));
            this.picBoxCredito.Location = new System.Drawing.Point(14, 131);
            this.picBoxCredito.Name = "picBoxCredito";
            this.picBoxCredito.Size = new System.Drawing.Size(20, 20);
            this.picBoxCredito.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBoxCredito.TabIndex = 9;
            this.picBoxCredito.TabStop = false;
            // 
            // lblValorDinheiro
            // 
            this.lblValorDinheiro.AutoSize = true;
            this.lblValorDinheiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorDinheiro.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblValorDinheiro.Location = new System.Drawing.Point(159, 77);
            this.lblValorDinheiro.Name = "lblValorDinheiro";
            this.lblValorDinheiro.Size = new System.Drawing.Size(36, 16);
            this.lblValorDinheiro.TabIndex = 8;
            this.lblValorDinheiro.Text = "0,00";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel8.Location = new System.Drawing.Point(75, 116);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(140, 1);
            this.panel8.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label2.Location = new System.Drawing.Point(14, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Cartões";
            // 
            // picBoxDinheiro
            // 
            this.picBoxDinheiro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picBoxDinheiro.ErrorImage = null;
            this.picBoxDinheiro.Image = ((System.Drawing.Image)(resources.GetObject("picBoxDinheiro.Image")));
            this.picBoxDinheiro.InitialImage = ((System.Drawing.Image)(resources.GetObject("picBoxDinheiro.InitialImage")));
            this.picBoxDinheiro.Location = new System.Drawing.Point(14, 74);
            this.picBoxDinheiro.Name = "picBoxDinheiro";
            this.picBoxDinheiro.Size = new System.Drawing.Size(20, 20);
            this.picBoxDinheiro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBoxDinheiro.TabIndex = 6;
            this.picBoxDinheiro.TabStop = false;
            // 
            // lblDinheiro1
            // 
            this.lblDinheiro1.AutoSize = true;
            this.lblDinheiro1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F);
            this.lblDinheiro1.Location = new System.Drawing.Point(40, 77);
            this.lblDinheiro1.Name = "lblDinheiro1";
            this.lblDinheiro1.Size = new System.Drawing.Size(58, 16);
            this.lblDinheiro1.TabIndex = 5;
            this.lblDinheiro1.Text = "Dinheiro";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(250, 1);
            this.panel5.TabIndex = 3;
            // 
            // lblDinheiro
            // 
            this.lblDinheiro.AutoSize = true;
            this.lblDinheiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDinheiro.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblDinheiro.Location = new System.Drawing.Point(14, 52);
            this.lblDinheiro.Name = "lblDinheiro";
            this.lblDinheiro.Size = new System.Drawing.Size(62, 15);
            this.lblDinheiro.TabIndex = 4;
            this.lblDinheiro.Text = "Dinheiro";
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.lblValor.Location = new System.Drawing.Point(169, 11);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(40, 16);
            this.lblValor.TabIndex = 3;
            this.lblValor.Text = "Valor";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(0, 30);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(250, 1);
            this.panel3.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel4.Location = new System.Drawing.Point(76, 61);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(140, 1);
            this.panel4.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(153, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1, 23);
            this.panel1.TabIndex = 1;
            // 
            // lblFormaDePagamento
            // 
            this.lblFormaDePagamento.AutoSize = true;
            this.lblFormaDePagamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormaDePagamento.Location = new System.Drawing.Point(7, 11);
            this.lblFormaDePagamento.Name = "lblFormaDePagamento";
            this.lblFormaDePagamento.Size = new System.Drawing.Size(139, 16);
            this.lblFormaDePagamento.TabIndex = 0;
            this.lblFormaDePagamento.Text = "Forma de Pagamento";
            // 
            // frmFecharCaixa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(799, 450);
            this.Controls.Add(this.pnlFechaCaixa);
            this.Name = "frmFecharCaixa";
            this.Text = "frmFechaCaixa";
            this.pnlFechaCaixa.ResumeLayout(false);
            this.pnlFechaCaixa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCaixa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxDinheiroRetirada)).EndInit();
            this.grpGanhos.ResumeLayout(false);
            this.grpGanhos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPix)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxDebito)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCredito)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxDinheiro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlFechaCaixa;
        private System.Windows.Forms.GroupBox grpGanhos;
        private System.Windows.Forms.Label lblDinheiro;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblFormaDePagamento;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox picBoxDinheiro;
        private System.Windows.Forms.Label lblDinheiro1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lblValorDinheiro;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblGanhosHj;
        private System.Windows.Forms.PictureBox picBoxCredito;
        private System.Windows.Forms.Label lblCredito;
        private System.Windows.Forms.Label lblValorTotal;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblValorDebito;
        private System.Windows.Forms.Label lblDebito;
        private System.Windows.Forms.PictureBox picBoxDebito;
        private System.Windows.Forms.Label lblValorCredito;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label lblFechamentoDeCaixa;
        private System.Windows.Forms.PictureBox picBoxDinheiroRetirada;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.PictureBox picBoxCaixa;
        private System.Windows.Forms.Label lblDinheiroRetirada;
        private System.Windows.Forms.Label lblRetirada;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label lblCaixa;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label lblValorCaixa;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Button btnAvancar;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.PictureBox picBoxPix;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label lblPix;
        private System.Windows.Forms.Label lblPixIcon;
        private System.Windows.Forms.Label lblPixValor;
    }
}