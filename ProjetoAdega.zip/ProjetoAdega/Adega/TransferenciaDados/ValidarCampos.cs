﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

 /* namespace TransferenciaDados
{
        public class ValidarCampos(Form form)
        {
            if (string.IsNullOrEmpty(funcionario.)) //Verifica se há conteúdo na variável.
                return 1;
            if (string.IsNullOrEmpty(funcionario.Endereco)) //Verifica se há conteúdo na variável.
                return 2;
            if (string.IsNullOrEmpty(funcionario.Cargo)) //Verifica se há conteúdo na variável.
                return 3;
            if (funcionario.Salario <= 0) //Verifica se o valor do salário é valido.
                return 4;
            if (funcionario.Idade < 18) //Verifica se o funcionário é maior de idade.
                return 5;

            return 0; //Todos os campos atende os requisitos das regras.
        }
    }*/

