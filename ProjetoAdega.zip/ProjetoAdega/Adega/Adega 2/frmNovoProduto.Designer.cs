﻿
namespace Adega_2
{
    partial class frmNovoProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNovoProduto));
            this.pnlAddProduto = new System.Windows.Forms.Panel();
            this.txtPrecoAddProdutoGelado = new System.Windows.Forms.TextBox();
            this.txtPrecoAddProdutoCusto = new System.Windows.Forms.TextBox();
            this.lblPrecoAddProdutoGelado = new System.Windows.Forms.Label();
            this.lblPrecoAddProdutoCusto = new System.Windows.Forms.Label();
            this.cboCategorias = new System.Windows.Forms.ComboBox();
            this.txtQntdEstoqueAddProduto = new System.Windows.Forms.TextBox();
            this.lblQtndEstoqueAddProduto = new System.Windows.Forms.Label();
            this.btnVoltarAddProduto = new System.Windows.Forms.Button();
            this.btnLimparAddProduto = new System.Windows.Forms.Button();
            this.btnAdicionarAddProdutos = new System.Windows.Forms.Button();
            this.lblCategoriaAddProduto = new System.Windows.Forms.Label();
            this.txtPrecoAddProdutoQuente = new System.Windows.Forms.TextBox();
            this.lblPrecoAddProdutoQuente = new System.Windows.Forms.Label();
            this.txtUnidadeAddProduto = new System.Windows.Forms.TextBox();
            this.lblUnidadeAddProduto = new System.Windows.Forms.Label();
            this.txtNomeAddProduto = new System.Windows.Forms.TextBox();
            this.lblNomeAddProduto = new System.Windows.Forms.Label();
            this.lblAdicionarProduto = new System.Windows.Forms.Label();
            this.pnlAddProduto.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlAddProduto
            // 
            this.pnlAddProduto.Controls.Add(this.txtPrecoAddProdutoGelado);
            this.pnlAddProduto.Controls.Add(this.txtPrecoAddProdutoCusto);
            this.pnlAddProduto.Controls.Add(this.lblPrecoAddProdutoGelado);
            this.pnlAddProduto.Controls.Add(this.lblPrecoAddProdutoCusto);
            this.pnlAddProduto.Controls.Add(this.cboCategorias);
            this.pnlAddProduto.Controls.Add(this.txtQntdEstoqueAddProduto);
            this.pnlAddProduto.Controls.Add(this.lblQtndEstoqueAddProduto);
            this.pnlAddProduto.Controls.Add(this.btnVoltarAddProduto);
            this.pnlAddProduto.Controls.Add(this.btnLimparAddProduto);
            this.pnlAddProduto.Controls.Add(this.btnAdicionarAddProdutos);
            this.pnlAddProduto.Controls.Add(this.lblCategoriaAddProduto);
            this.pnlAddProduto.Controls.Add(this.txtPrecoAddProdutoQuente);
            this.pnlAddProduto.Controls.Add(this.lblPrecoAddProdutoQuente);
            this.pnlAddProduto.Controls.Add(this.txtUnidadeAddProduto);
            this.pnlAddProduto.Controls.Add(this.lblUnidadeAddProduto);
            this.pnlAddProduto.Controls.Add(this.txtNomeAddProduto);
            this.pnlAddProduto.Controls.Add(this.lblNomeAddProduto);
            this.pnlAddProduto.Controls.Add(this.lblAdicionarProduto);
            this.pnlAddProduto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAddProduto.Location = new System.Drawing.Point(0, 0);
            this.pnlAddProduto.Name = "pnlAddProduto";
            this.pnlAddProduto.Size = new System.Drawing.Size(829, 419);
            this.pnlAddProduto.TabIndex = 0;
            // 
            // txtPrecoAddProdutoGelado
            // 
            this.txtPrecoAddProdutoGelado.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtPrecoAddProdutoGelado.Location = new System.Drawing.Point(396, 150);
            this.txtPrecoAddProdutoGelado.Name = "txtPrecoAddProdutoGelado";
            this.txtPrecoAddProdutoGelado.Size = new System.Drawing.Size(81, 27);
            this.txtPrecoAddProdutoGelado.TabIndex = 33;
            this.txtPrecoAddProdutoGelado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrecoAddProdutoGelado_num);
            // 
            // txtPrecoAddProdutoCusto
            // 
            this.txtPrecoAddProdutoCusto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtPrecoAddProdutoCusto.Location = new System.Drawing.Point(502, 150);
            this.txtPrecoAddProdutoCusto.Name = "txtPrecoAddProdutoCusto";
            this.txtPrecoAddProdutoCusto.Size = new System.Drawing.Size(81, 27);
            this.txtPrecoAddProdutoCusto.TabIndex = 32;
            this.txtPrecoAddProdutoCusto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrecoAddProdutoCusto_num);
            // 
            // lblPrecoAddProdutoGelado
            // 
            this.lblPrecoAddProdutoGelado.AutoSize = true;
            this.lblPrecoAddProdutoGelado.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoAddProdutoGelado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(0)))));
            this.lblPrecoAddProdutoGelado.Location = new System.Drawing.Point(393, 120);
            this.lblPrecoAddProdutoGelado.Name = "lblPrecoAddProdutoGelado";
            this.lblPrecoAddProdutoGelado.Size = new System.Drawing.Size(95, 17);
            this.lblPrecoAddProdutoGelado.TabIndex = 31;
            this.lblPrecoAddProdutoGelado.Text = "Preço Gelado";
            // 
            // lblPrecoAddProdutoCusto
            // 
            this.lblPrecoAddProdutoCusto.AutoSize = true;
            this.lblPrecoAddProdutoCusto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoAddProdutoCusto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(0)))));
            this.lblPrecoAddProdutoCusto.Location = new System.Drawing.Point(499, 120);
            this.lblPrecoAddProdutoCusto.Name = "lblPrecoAddProdutoCusto";
            this.lblPrecoAddProdutoCusto.Size = new System.Drawing.Size(105, 17);
            this.lblPrecoAddProdutoCusto.TabIndex = 29;
            this.lblPrecoAddProdutoCusto.Text = "Preço de Custo";
            // 
            // cboCategorias
            // 
            this.cboCategorias.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.cboCategorias.FormattingEnabled = true;
            this.cboCategorias.Location = new System.Drawing.Point(726, 150);
            this.cboCategorias.Name = "cboCategorias";
            this.cboCategorias.Size = new System.Drawing.Size(100, 28);
            this.cboCategorias.TabIndex = 28;
            this.cboCategorias.SelectedIndexChanged += new System.EventHandler(this.cboCategorias_SelectedIndexChanged);
            // 
            // txtQntdEstoqueAddProduto
            // 
            this.txtQntdEstoqueAddProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtQntdEstoqueAddProduto.Location = new System.Drawing.Point(609, 150);
            this.txtQntdEstoqueAddProduto.Name = "txtQntdEstoqueAddProduto";
            this.txtQntdEstoqueAddProduto.Size = new System.Drawing.Size(100, 27);
            this.txtQntdEstoqueAddProduto.TabIndex = 27;
            this.txtQntdEstoqueAddProduto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQntdEstoqueAddProduto_KeyPress);
            // 
            // lblQtndEstoqueAddProduto
            // 
            this.lblQtndEstoqueAddProduto.AutoSize = true;
            this.lblQtndEstoqueAddProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtndEstoqueAddProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(0)))));
            this.lblQtndEstoqueAddProduto.Location = new System.Drawing.Point(614, 120);
            this.lblQtndEstoqueAddProduto.Name = "lblQtndEstoqueAddProduto";
            this.lblQtndEstoqueAddProduto.Size = new System.Drawing.Size(94, 17);
            this.lblQtndEstoqueAddProduto.TabIndex = 26;
            this.lblQtndEstoqueAddProduto.Text = "Qntd estoque";
            // 
            // btnVoltarAddProduto
            // 
            this.btnVoltarAddProduto.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnVoltarAddProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVoltarAddProduto.ForeColor = System.Drawing.Color.White;
            this.btnVoltarAddProduto.Image = ((System.Drawing.Image)(resources.GetObject("btnVoltarAddProduto.Image")));
            this.btnVoltarAddProduto.Location = new System.Drawing.Point(39, 232);
            this.btnVoltarAddProduto.Name = "btnVoltarAddProduto";
            this.btnVoltarAddProduto.Size = new System.Drawing.Size(100, 48);
            this.btnVoltarAddProduto.TabIndex = 24;
            this.btnVoltarAddProduto.Text = "Voltar";
            this.btnVoltarAddProduto.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnVoltarAddProduto.UseVisualStyleBackColor = true;
            this.btnVoltarAddProduto.Click += new System.EventHandler(this.btnVoltarAddProduto_Click);
            // 
            // btnLimparAddProduto
            // 
            this.btnLimparAddProduto.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnLimparAddProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimparAddProduto.ForeColor = System.Drawing.Color.White;
            this.btnLimparAddProduto.Location = new System.Drawing.Point(423, 232);
            this.btnLimparAddProduto.Name = "btnLimparAddProduto";
            this.btnLimparAddProduto.Size = new System.Drawing.Size(89, 48);
            this.btnLimparAddProduto.TabIndex = 23;
            this.btnLimparAddProduto.Text = "Limpar";
            this.btnLimparAddProduto.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnLimparAddProduto.UseVisualStyleBackColor = true;
            this.btnLimparAddProduto.Click += new System.EventHandler(this.btnLimparAddProduto_Click);
            // 
            // btnAdicionarAddProdutos
            // 
            this.btnAdicionarAddProdutos.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAdicionarAddProdutos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdicionarAddProdutos.ForeColor = System.Drawing.Color.White;
            this.btnAdicionarAddProdutos.Image = ((System.Drawing.Image)(resources.GetObject("btnAdicionarAddProdutos.Image")));
            this.btnAdicionarAddProdutos.Location = new System.Drawing.Point(533, 232);
            this.btnAdicionarAddProdutos.Name = "btnAdicionarAddProdutos";
            this.btnAdicionarAddProdutos.Size = new System.Drawing.Size(152, 48);
            this.btnAdicionarAddProdutos.TabIndex = 21;
            this.btnAdicionarAddProdutos.Text = "Adicionar produto";
            this.btnAdicionarAddProdutos.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnAdicionarAddProdutos.UseVisualStyleBackColor = true;
            this.btnAdicionarAddProdutos.Click += new System.EventHandler(this.btnAdicionarAddProdutos_Click);
            // 
            // lblCategoriaAddProduto
            // 
            this.lblCategoriaAddProduto.AutoSize = true;
            this.lblCategoriaAddProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoriaAddProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(0)))));
            this.lblCategoriaAddProduto.Location = new System.Drawing.Point(723, 120);
            this.lblCategoriaAddProduto.Name = "lblCategoriaAddProduto";
            this.lblCategoriaAddProduto.Size = new System.Drawing.Size(69, 17);
            this.lblCategoriaAddProduto.TabIndex = 19;
            this.lblCategoriaAddProduto.Text = "Categoria";
            // 
            // txtPrecoAddProdutoQuente
            // 
            this.txtPrecoAddProdutoQuente.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtPrecoAddProdutoQuente.Location = new System.Drawing.Point(289, 150);
            this.txtPrecoAddProdutoQuente.Name = "txtPrecoAddProdutoQuente";
            this.txtPrecoAddProdutoQuente.Size = new System.Drawing.Size(81, 27);
            this.txtPrecoAddProdutoQuente.TabIndex = 18;
            this.txtPrecoAddProdutoQuente.TextChanged += new System.EventHandler(this.txtPrecoAddProdutoQuente_TextChanged);
            this.txtPrecoAddProdutoQuente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrecoAddProdutoQuente_num);
            // 
            // lblPrecoAddProdutoQuente
            // 
            this.lblPrecoAddProdutoQuente.AutoSize = true;
            this.lblPrecoAddProdutoQuente.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoAddProdutoQuente.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(0)))));
            this.lblPrecoAddProdutoQuente.Location = new System.Drawing.Point(286, 120);
            this.lblPrecoAddProdutoQuente.Name = "lblPrecoAddProdutoQuente";
            this.lblPrecoAddProdutoQuente.Size = new System.Drawing.Size(96, 17);
            this.lblPrecoAddProdutoQuente.TabIndex = 17;
            this.lblPrecoAddProdutoQuente.Text = "Preço Quente";
            // 
            // txtUnidadeAddProduto
            // 
            this.txtUnidadeAddProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtUnidadeAddProduto.Location = new System.Drawing.Point(161, 150);
            this.txtUnidadeAddProduto.Name = "txtUnidadeAddProduto";
            this.txtUnidadeAddProduto.Size = new System.Drawing.Size(100, 27);
            this.txtUnidadeAddProduto.TabIndex = 16;
            // 
            // lblUnidadeAddProduto
            // 
            this.lblUnidadeAddProduto.AutoSize = true;
            this.lblUnidadeAddProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnidadeAddProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(0)))));
            this.lblUnidadeAddProduto.Location = new System.Drawing.Point(158, 120);
            this.lblUnidadeAddProduto.Name = "lblUnidadeAddProduto";
            this.lblUnidadeAddProduto.Size = new System.Drawing.Size(61, 17);
            this.lblUnidadeAddProduto.TabIndex = 15;
            this.lblUnidadeAddProduto.Text = "Unidade";
            // 
            // txtNomeAddProduto
            // 
            this.txtNomeAddProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtNomeAddProduto.Location = new System.Drawing.Point(39, 150);
            this.txtNomeAddProduto.Name = "txtNomeAddProduto";
            this.txtNomeAddProduto.Size = new System.Drawing.Size(100, 27);
            this.txtNomeAddProduto.TabIndex = 14;
            // 
            // lblNomeAddProduto
            // 
            this.lblNomeAddProduto.AutoSize = true;
            this.lblNomeAddProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeAddProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(0)))));
            this.lblNomeAddProduto.Location = new System.Drawing.Point(36, 120);
            this.lblNomeAddProduto.Name = "lblNomeAddProduto";
            this.lblNomeAddProduto.Size = new System.Drawing.Size(45, 17);
            this.lblNomeAddProduto.TabIndex = 13;
            this.lblNomeAddProduto.Text = "Nome";
            // 
            // lblAdicionarProduto
            // 
            this.lblAdicionarProduto.AutoSize = true;
            this.lblAdicionarProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdicionarProduto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(0)))));
            this.lblAdicionarProduto.Location = new System.Drawing.Point(53, 43);
            this.lblAdicionarProduto.Name = "lblAdicionarProduto";
            this.lblAdicionarProduto.Size = new System.Drawing.Size(226, 31);
            this.lblAdicionarProduto.TabIndex = 12;
            this.lblAdicionarProduto.Text = "Adicionar produto";
            // 
            // frmNovoProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.ClientSize = new System.Drawing.Size(829, 419);
            this.Controls.Add(this.pnlAddProduto);
            this.Name = "frmNovoProduto";
            this.Text = "frmAdicionarProduto";
            this.Load += new System.EventHandler(this.frmNovoProduto_Load);
            this.pnlAddProduto.ResumeLayout(false);
            this.pnlAddProduto.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAddProduto;
        private System.Windows.Forms.Button btnLimparAddProduto;
        private System.Windows.Forms.Button btnAdicionarAddProdutos;
        private System.Windows.Forms.Label lblCategoriaAddProduto;
        private System.Windows.Forms.TextBox txtPrecoAddProdutoQuente;
        private System.Windows.Forms.Label lblPrecoAddProdutoQuente;
        private System.Windows.Forms.TextBox txtUnidadeAddProduto;
        private System.Windows.Forms.Label lblUnidadeAddProduto;
        private System.Windows.Forms.TextBox txtNomeAddProduto;
        private System.Windows.Forms.Label lblNomeAddProduto;
        private System.Windows.Forms.Label lblAdicionarProduto;
        private System.Windows.Forms.Button btnVoltarAddProduto;
        private System.Windows.Forms.TextBox txtQntdEstoqueAddProduto;
        private System.Windows.Forms.Label lblQtndEstoqueAddProduto;
        private System.Windows.Forms.ComboBox cboCategorias;
        private System.Windows.Forms.TextBox txtPrecoAddProdutoGelado;
        private System.Windows.Forms.TextBox txtPrecoAddProdutoCusto;
        private System.Windows.Forms.Label lblPrecoAddProdutoGelado;
        private System.Windows.Forms.Label lblPrecoAddProdutoCusto;
    }
}